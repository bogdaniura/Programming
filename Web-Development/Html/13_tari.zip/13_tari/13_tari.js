const express = require('express') // pentru express web framework | Aplicatia este un server web.
var fs = require('fs') // pentru a putea accesa fisiere
const Database = require('better-sqlite3') // pentru a folosi baze de date sqlite
var cndv = require('./cndv.js') // pentru a folosi functia noastra, care pregateste tabelul

const app = express() // obiectul aplicatie
const port = 3000 // portul la care asculta aplicatia

const db = new Database('./atestat.db', { verbose: console.log }) // | optiunea prezinta interogarile 

var start = fs.readFileSync('./start.html') // Citim fisierul, care va fi inceputul stringului raspuns.
var end = `</body>` // Sfarsitul stringului raspuns.

app.use(express.urlencoded({ extended: true })) // Ca sa preia ce s-a trimis cu post. Daca nu punem optiunea, primim mesaj "deprecated".
app.use(express.static(__dirname)) // Ca sa transmita fisierul css.

app.get('/d', function (req, res) {
    res.send(__dirname)
})

app.get('/13_tari_a', function (req, res) {
    res.sendFile('13_tari_a.htm', { root: __dirname })
})

app.post('/13_tari_a', (req, res) => { // post = se transmit date din formular | adresa | req = ceea ce se transmite, un obiect
    var denumire = req.body.denumire // variabile care retin ceea ce am primit din formular
    var continent = req.body.continent
    var capitala = req.body.capitala
    var locuitori = req.body.locuitori
    var stmt = db.prepare(`
        INSERT INTO tari
        VALUES (?, ?, ?, ?)
    `) // Pregatim instructiunea.
    stmt.run(denumire, continent, capitala, locuitori); // Se executa instructiunea, folosind parametri.

    stmt = db.prepare(`
        SELECT *
        FROM tari
    `) // Pregatim instructiunea.
    var tari = stmt.all() // Se executa instructiunea.
    var t = cndv.tabel(tari) // Rezultatul returnat este un vector de linii. Obtinem codul HTML al tabelului.
    t = t + `<p>${__dirname}<\p>`   

    res.send(start + t + end) // Concatenam si transmitem browserului.
    res.end()
    return
})

app.listen(port, () => { 
    var d = new Date()
    h = d.getHours()
    m = d.getMinutes()
    s = d.getSeconds()
    console.log(`${h}:${m}:${s}`)
    console.log(`Aplicatia asteapta la http://localhost:${port}`)
})
