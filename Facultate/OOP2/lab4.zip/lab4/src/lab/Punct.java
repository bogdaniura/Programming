package lab;

public class Punct {
    int x, y;
    
    public Punct(int x, int y) {
        this.x = x;
        this.y = y;
    }
    
    
    
}
